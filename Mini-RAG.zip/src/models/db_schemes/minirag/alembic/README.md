Generic single-database configuration.
