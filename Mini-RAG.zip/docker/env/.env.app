APP_NAME="mini-RAG"
APP_ENV="development"

FILE_ALLOWED_TYPES=["text/plain", "application/pdf"]
FILE_MAX_SIZE=10
FILE_DEFAULT_CHUNK=512000 # 512KB

POSTGRES_USERNAME="postgres"
POSTGRES_PASSWORD="postgres_password"
POSTGRES_HOST="pgvector"
POSTGRES_PORT=5432
POSTGRES_MAIN_DATABASE="minirag"

# ============================== LLM Config ================================
GENERATION_BACKEND="COHERE"
EMBEDDING_BACKEND="COHERE"
RERANKER_BACKEND="COHERE"

OPENAI_API_KEY="key___"
OPENAI_API_URL=
COHERE_API_KEY="irmyl4w93m5ePUOV0wZXFivsaRFWXc7OYlH3dmw0"

GENERATION_MODEL_ID_LITERAL=["gpt-3.5-turbo-0125", "gpt-3.5"]
GENERATION_MODEL_ID="command-r-plus-08-2024"
EMBEDDING_MODEL_ID="embed-multilingual-v3.0"
RERANKER_MODEL_ID="rerank-multilingual-v3.0"
EMBEDDING_MODEL_SIZE=1024

INPUT_DAFAULT_MAX_CHARACTERS=16000
GENERATION_DAFAULT_MAX_TOKENS=4096
GENERATION_DAFAULT_TEMPERATURE=0.5

# ============================== Vector DB Config ================================
VECTOR_DB_BACKEND_LITERAL=["QDRANT", "PGVECTOR"]
VECTOR_DB_BACKEND="PGVECTOR"
VECTOR_DB_PATH="PGVECTOR"
VECTOR_DB_DISTANCE_METHOD="cosine"
VECTOR_DB_PGVEC_INDEX_THRESHOLD = 300

# ============================== Template Config ================================
PRIMARY_LANG = "en"
DEFAULT_LANG = "en"


NAPKIN_API_KEY="sk-56915a0705f2b10e2b8217207d618cda9a2bc766661cf7d3d3155a103a80e5a4"
